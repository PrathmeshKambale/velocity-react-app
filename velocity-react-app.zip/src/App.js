import React from "react";

function App() {
  return (
    <div>
      <h1>Hello Velocity 🚀</h1>
      <p>This is a sample React project ready for GitHub.</p>
    </div>
  );
}

export default App;