# Velocity React App

This is a sample React app created for practice and GitHub push.

## Run locally

```bash
npm install
npm start
```

App will start on `http://localhost:3000` 🚀
